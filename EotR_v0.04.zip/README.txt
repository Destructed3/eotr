CHANGELOG:
v0.04
- GuV �berarbeitet und verbessert
 -> Geb�udekosten pro Jahr werden nicht angezeigt
- Jobs sind jetzt Regionen zugeordnet und werden in der Regionen-Ansicht zugeteilt
- Tooltips im Kurserstellungs-Menu hinzugef�gt, welche die Nachfrage nach Kursen zum jeweiligen Attribut anzeigen
- speichern gibt jetzt ein Feedback �ber Erfolg/Misserfolg
- Verbesserung des Journals
- exception handling verbessert
- diverse Bugfixes


Tutorial:
Das Teil ist v�llig verbuggt. Da ich ne faule Sau bin, wirst du aber meist nicht mehr davon mitbekommen als dass das Spiel einfriert. Was leider vermutlich �fters der Fall sein wird. Das Spiel wird beim Jahreswechsel vermutlich am h�ufigsten einfrieren, da hier einfach das meiste passiert.

Du startest das Spiel nur mit dir und einer H�tte, in der du wohnst. Wenn du willst, schau dir deinen Char im "Inhabitants"-Menu an. Er hat nen Namen und Stats und ein Journal, das wohl in die Kategorie "nett aber nutzlos" geh�rt. Wenn du dir die verf�gbaren Lehrer anschaust, erkennst du dass die stats deines Chars schei�e sind. Das ist nicht intended, das ist Faulheit. Daf�r kostet er keinen Lohn.

Damit im kommenden Jahr Studenten dazusto�en k�nnen, solltest du einen Schlafsaal bauen. Das machst du unter Rooms -> Build Rooms und hier einen der Dorms.

Wenn du nicht m�chtest das dein Held solange unt�tig ist, kannst du ihn unter Regionen -> Regionen Menu -> Startregion anzeigen lassen. Jobs bringen Geld auf Basis des Attributes auf dem sie basieren. Guard=Physical, Advisor=Mental, Bard=Social, Sorcerer=Magic. Die verf�gbaren Jobs siehst du oben. Unten markierst du durch ein K�stchen den gew�nschten Job und w�hlst dann durch klicken auf den Studenplan einen Tag aus, an dem der Job durchgef�hrt werden soll. Ein Job nimmt immer einen ganzen Tag in Anspruch. Bedenke das Jobs die du nicht verbrauchst deinen Studenten zur Verf�gung stehen. Einige werden das brauchen um ihre Studiengeb�hren zu bezahlen.

Sobald du gebaut hast, was du bauen m�chtest und Jobs f�r deinen Helden zugeteilt hast, kannst du das Jahr rechts oben beenden.

Da nun Studenten da sind und du ihnen sonst nichts bieten kannst, solltest du nun Kurse erschaffen. Um Kurse erschaffen zu k�nnen brauchst du 
1) einen Lehrer
2) einen Raum (Kursraum oder H�rsaal)
3) einen Zeitraum, in dem beide gleichzeitig verf�gbar sind

Den Raum baust du wie du ebenfalls unter Rooms -> Build Rooms. Unter Courses -> Create Course kommst du in die Maske zum erstellen neuer Kurse. Solange du keinen Kursraum oder H�rsaal gebaut hast, ist sie gesperrt. Du kannst mit den Optionen hier herumspielen. Einen Zeitraum w�hlst du aus, indem du wiederum auf den Studenplan klickst. Felder die im Moment beschriftet sind, gelten f�r das Programm hierbei als geblockt, dazu geh�rt auch deine eigene Markierung.

Wenn du dann reich wurdest, kannst du noch weitere Heldenquartiere bauen und noch mehr Helden anheuern und noch mehr Jobs erledigen und Kurse anbieten. Yay!
Ein Wehrmutstropfen ist, das alle anderen Helden viel besser sind als dein eigener. Eines Tages werde ich das verbessern. Heute ist nicht dieser Tag!

So. Damit kennst du alle bisherigen Inhalte. Viel spa� damit!

Greetings Hannes

P.S.: 
Ich hab unter 

https://docs.google.com/spreadsheets/d/1__dhsDjm_FUj7G90QDYkyo-Q2JJCPk0CFYMarsUoH4k/edit?usp=sharing 

ne Datei angefangen in der ich versuche die Bugs aufzuschreiben um sie halbwegs systematisch angehen zu k�nnen. Wenn du zu viel Zeit hast schreib dazu was du findest!






